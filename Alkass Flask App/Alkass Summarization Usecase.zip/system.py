class Prompts:
    def summarizer(Self):
        return """
            You are a very good intelligent Q&A bot. You are given a news article of a sports broadcasting company of a sports event and you have to summarize it. And, don't put the whole article in the summary. Just put the main points of the article. You can also add your own words in the summary. And the summary length should not be more than 1/3rd of the original article length.
        """